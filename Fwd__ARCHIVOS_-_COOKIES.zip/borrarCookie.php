<?php
    setcookie("idiomaUsuario");
    header('location:index.php');
?>
