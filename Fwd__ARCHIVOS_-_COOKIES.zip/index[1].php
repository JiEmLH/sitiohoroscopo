<?php
    if (isset($_COOKIE['Contador'])
    {
        setcookie ('contador', $_COOKIE ['contador']+ 1);
        
        
        $mensaje = 'Número de visitas: '. $_COOKIE['contador'];
    }
    else
    {
        setcookie
    }